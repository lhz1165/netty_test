package org.bigdash.security15.abac.abac.function;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.googlecode.aviator.runtime.function.AbstractFunction;
import com.googlecode.aviator.runtime.function.FunctionUtils;
import com.googlecode.aviator.runtime.type.AviatorBoolean;
import com.googlecode.aviator.runtime.type.AviatorObject;

public class KeyMatchFunction extends AbstractFunction {
    private static final long serialVersionUID = 3150047024665708104L;

    @Override
    public AviatorObject call(Map<String, Object> env, AviatorObject arg1, AviatorObject arg2) {
        String key1 = FunctionUtils.getStringValue(arg1, env);
        String key2 = FunctionUtils.getStringValue(arg2, env);
        // 策略为空，不参与校验
        if (StringUtils.isBlank(key2)) {
            return AviatorBoolean.valueOf(true);
        }
        return AviatorBoolean.valueOf(keyMatch(key1, key2));
    }

    @Override
    public String getName() {
        return "keyMatch";
    }

    private boolean keyMatch(String key1, String key2) {
        int i = key2.indexOf('*');
        if (i == -1) {
            return key1.equals(key2);
        }

        if (key1.length() > i) {
            return key1.substring(0, i).equals(key2.substring(0, i));
        }
        return key1.equals(key2.substring(0, i));
    }

}