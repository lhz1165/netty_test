package org.bigdash.security15.abac.abac.entity;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class User implements Serializable {
    private static final long serialVersionUID = 996477149563879646L;
    private String tenant;
    private String username;
    private String password;
    private String authorities;
}
