package org.bigdash.security15.abac.abac.policy;

import java.io.File;
import java.util.Collections;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

import com.alibaba.fastjson.JSONArray;

import lombok.extern.slf4j.Slf4j;

/**
 * 从本地json文件加载策略
 */
@Slf4j
@Component
public class LocalPolicyFactory implements PolicyFactory {

    private List<PolicyRule> rules = null;

    @Override
    public List<PolicyRule> getAllPolicyRules() {
        if (rules != null) {
            return rules;
        }
        // 加载本地策略文件
        try {
            File file = ResourceUtils.getFile("classpath:default-policy.json");
            String policys = FileUtils.readFileToString(file, "utf-8");
            rules = JSONArray.parseArray(policys, PolicyRule.class);
            return rules;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return Collections.emptyList();
        }
    }

}
