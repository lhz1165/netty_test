package org.bigdash.security15.abac.abac;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.bigdash.security15.abac.abac.function.KeyMatchFunction;
import org.bigdash.security15.abac.abac.function.RegexMatchFunction;
import org.bigdash.security15.abac.abac.policy.LocalPolicyFactory;
import org.bigdash.security15.abac.abac.policy.PolicyRule;
import org.springframework.stereotype.Component;

import com.googlecode.aviator.AviatorEvaluator;
import com.googlecode.aviator.AviatorEvaluatorInstance;
import com.googlecode.aviator.Expression;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class PolicyEnforcement {

    @Resource
    private LocalPolicyFactory localPolicyFactory;

    public boolean check(MyUserDetails userDetails, Object action, Map<String, Object> requestParams) {
        // 加载用户策略 TODO 可以根据当前登录用户加载用户自己的策略（MySQL、Redis、File等）
        List<PolicyRule> allRules = localPolicyFactory.getAllPolicyRules();

        // 函数校验
        AviatorEvaluatorInstance aviatorEval = AviatorEvaluator.newInstance();
        // 添加自定义函数
        aviatorEval.addFunction(new KeyMatchFunction());
        aviatorEval.addFunction(new RegexMatchFunction());
        // 校验表达式
        for (PolicyRule rule : allRules) {
            Expression expression = aviatorEval.compile(rule.getExpression(), true);
            // 封装参数，包括请求参数与策略参数
            Map<String, Object> fullParams = new HashMap<>(requestParams);
            // 策略模型
            fullParams.put("p_tenant", rule.getTenant());
            fullParams.put("p_user", rule.getUser());
            fullParams.put("p_resource", rule.getResource());
            fullParams.put("p_action", rule.getAction());
            Boolean result = (Boolean)expression.execute(fullParams);
            if (result) {
                return Boolean.TRUE;
            }
        }
        return Boolean.FALSE;
    }

}
