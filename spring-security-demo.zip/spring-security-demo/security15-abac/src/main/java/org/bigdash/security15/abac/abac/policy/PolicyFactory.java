package org.bigdash.security15.abac.abac.policy;

import java.util.List;

public interface PolicyFactory {

    List<PolicyRule> getAllPolicyRules();

}
