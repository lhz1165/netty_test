package org.bigdash.security15.abac.abac.policy;

import lombok.Data;

@Data
public class PolicyRule {
    /**
     * 租户
     */
    private String tenant;
    /**
     * 用户组
     */
    private String group;
    /**
     * 用户
     */
    private String user;
    /**
     * 要访问的资源，可以使用 * 作为通配符，例如/users/*
     */
    private String resource;
    /**
     * 用户对资源执行的操作。HTTP方法，GET、POST、PUT、DELETE等，可以使用 * 作为通配符
     */
    private String action;
    /**
     * 表达式
     */
    private String expression;
}
