package org.bigdash.security15.abac.abac;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.alibaba.fastjson.JSONObject;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class AbacAuthenticationFilter extends OncePerRequestFilter {

    @Resource
    private PolicyEnforcement policyEnforcement;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
        throws ServletException, IOException {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null) {
            filterChain.doFilter(request, response);
            return;
        }

        MyUserDetails userDetails = (MyUserDetails)authentication.getPrincipal();

        // TODO 从request中获取参数模型

        // 请求模型
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("r_tenant", userDetails.getTenant());
        parameters.put("r_user", userDetails.getUsername());
        parameters.put("r_resource", request.getServletPath());
        parameters.put("r_action", request.getMethod());

        log.debug("hasPersmission({}, {}, {})", userDetails, null, parameters);

        // ABAC校验
        if (policyEnforcement.check(userDetails, null, parameters)) {
            filterChain.doFilter(request, response);
        } else {
            response.setContentType("application/json;charset=utf-8");
            try (PrintWriter out = response.getWriter()) {
                Map<String, Object> result = new HashMap<>(8);
                result.put("code", 100);
                result.put("msg", "权限不足");
                out.write(JSONObject.toJSONString(result));
                out.flush();
            }
        }
    }

}
