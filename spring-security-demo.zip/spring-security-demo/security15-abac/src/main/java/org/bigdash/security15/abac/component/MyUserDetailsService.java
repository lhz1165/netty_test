package org.bigdash.security15.abac.component;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.bigdash.security15.abac.abac.MyUserDetails;
import org.bigdash.security15.abac.abac.entity.User;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class MyUserDetailsService implements UserDetailsService {

    private Map<String, User> users = new HashMap<>(8);

    @Resource
    private PasswordEncoder passwordEncoder;

    @PostConstruct
    private void init() {
        // 模拟数据库数据（数据库保存加密密码）
        this.users = new HashMap<>();
        users.put("admin", new User("shunwang", "admin", "123456", "ROLE_admin"));
        users.put("dash", new User("shunwang", "dash", "123456", "ROLE_user"));
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        if (!users.containsKey(username)) {
            throw new UsernameNotFoundException("用户不存在");
        }

        // 从数据库加载用户
        User user = users.get(username);

        // 密码加密
        String password = passwordEncoder.encode(user.getPassword());

        return new MyUserDetails(user.getTenant(), user.getUsername(), password,
            AuthorityUtils.commaSeparatedStringToAuthorityList(user.getAuthorities()));
    }
}
