package org.bigdash.security15.abac.config;

import javax.annotation.Resource;

import org.bigdash.security15.abac.abac.AbacAuthenticationFilter;
import org.bigdash.security15.abac.handler.MyLoginFailureHandler;
import org.bigdash.security15.abac.handler.MyLoginSuccessHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
public class WebSecurityConfiguration extends WebSecurityConfigurerAdapter {

    @Resource
    private MyLoginSuccessHandler myLoginSuccessHandler;
    @Resource
    private MyLoginFailureHandler myLoginFailureHandler;
    @Resource
    private AbacAuthenticationFilter abacAuthenticationFilter;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.formLogin()
            // 自定义登录逻辑，给前端调用
            .loginProcessingUrl("/login")
            // 登录成功处理器
            .successHandler(myLoginSuccessHandler)
            // 登录失败处理器
            .failureHandler(myLoginFailureHandler);

        http.authorizeRequests()
            // 所有请求都必须被认证（登录）
            .anyRequest().authenticated();

        // 添加ABAC过滤器
        http.addFilterAfter(abacAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        // 关闭csrf保护
        http.csrf().disable();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

}