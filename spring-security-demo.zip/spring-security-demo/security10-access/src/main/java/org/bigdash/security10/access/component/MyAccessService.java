package org.bigdash.security10.access.component;

import java.util.Collection;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;

@Component
public class MyAccessService {

    public boolean canAccess(HttpServletRequest request, Authentication authentication) {
        String requestURI = request.getRequestURI();
        System.out.println("requestURI ->" + requestURI);
        // 获取用户权限
        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
        // 判断是否有权限
        return authorities.contains(new SimpleGrantedAuthority("admin"));
    }

}
