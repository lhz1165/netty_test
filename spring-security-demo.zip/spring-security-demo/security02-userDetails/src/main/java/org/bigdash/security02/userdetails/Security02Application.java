package org.bigdash.security02.userdetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 访问：localhost:8080
 *
 * 用户名：admin
 *
 * 密码：123456
 */
@SpringBootApplication
public class Security02Application {

    public static void main(String[] args) {
        SpringApplication.run(Security02Application.class, args);
    }

}