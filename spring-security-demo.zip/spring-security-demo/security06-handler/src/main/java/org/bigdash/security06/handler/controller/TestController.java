package org.bigdash.security06.handler.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

    @GetMapping("/goods")
    public String goods() {
        return "Here is Goods!";
    }

    @GetMapping("/account")
    public String account() {
        return "Here is Account!";
    }

}