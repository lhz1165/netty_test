package org.bigdash.security06.handler.component;

import javax.annotation.Resource;

import org.bigdash.security06.handler.exception.MyAuthenticationException;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class MyAuthenticationProvider implements AuthenticationProvider {

    @Resource
    private MyUserDetailsService myUserDetailsService;

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        String username = (String)authentication.getPrincipal();
        if (username == null || username.trim().equals("")) {
            throw new MyAuthenticationException("请输入账号！");
        }
        String password = (String)authentication.getCredentials();
        if (password == null || password.trim().equals("")) {
            throw new MyAuthenticationException("请输入密码！");
        }

        UserDetails userDetails = myUserDetailsService.loadUserByUsername(username);

        if (!new BCryptPasswordEncoder().matches(password, userDetails.getPassword())) {
            throw new BadCredentialsException("账号密码错误！");
        }

        return new UsernamePasswordAuthenticationToken(username, password, userDetails.getAuthorities());
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return true;
    }

}