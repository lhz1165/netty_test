package org.bigdash.security06.handler.handler;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;

@Component
public class MyAccessDeniedHandler implements AccessDeniedHandler {

    @Override
    public void handle(HttpServletRequest request, HttpServletResponse response,
        AccessDeniedException accessDeniedException) throws IOException {
        response.setContentType("application/json; charset=utf-8");
        try (PrintWriter out = response.getWriter()) {
            // 返回权限不足状态码，客户端根据状态码做响应的提示
            out.write("权限不足");
            out.flush();
        }
    }

}