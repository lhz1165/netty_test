package org.bigdash.security06.handler.exception;

import org.springframework.security.core.AuthenticationException;

public class MyAuthenticationException extends AuthenticationException {

    private static final long serialVersionUID = 5015038263043595732L;

    public MyAuthenticationException(String msg) {
        super(msg);
    }

}