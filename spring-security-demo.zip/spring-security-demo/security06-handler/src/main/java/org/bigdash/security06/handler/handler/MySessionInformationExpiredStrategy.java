package org.bigdash.security06.handler.handler;

import java.io.IOException;
import java.io.PrintWriter;

import org.springframework.security.web.session.SessionInformationExpiredEvent;
import org.springframework.security.web.session.SessionInformationExpiredStrategy;
import org.springframework.stereotype.Component;

@Component
public class MySessionInformationExpiredStrategy implements SessionInformationExpiredStrategy {

    @Override
    public void onExpiredSessionDetected(SessionInformationExpiredEvent event) throws IOException {
        event.getResponse().setContentType("application/json; charset=utf-8");
        try (PrintWriter out = event.getResponse().getWriter()) {
            out.write("账号已在其他地方登录");
            out.flush();
        }

        // 也可以踢掉前面登录的人
        // event.getSessionInformation().expireNow();
    }

}
