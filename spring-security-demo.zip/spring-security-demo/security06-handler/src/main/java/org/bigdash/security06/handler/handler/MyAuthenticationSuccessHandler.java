package org.bigdash.security06.handler.handler;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

@Component
public class MyAuthenticationSuccessHandler implements AuthenticationSuccessHandler {

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
        Authentication authentication) throws IOException {
        response.setContentType("application/json;charset=utf-8");
        try (PrintWriter out = response.getWriter()) {
            out.write("登录成功!");
            out.flush();
        }

        System.out.println("authorities -> " + authentication.getAuthorities());
        System.out.println("credentials -> " + authentication.getCredentials());// 基于安全考虑，显示null
        System.out.println("details -> " + authentication.getDetails());
        System.out.println("principal -> " + authentication.getPrincipal());
    }

}
