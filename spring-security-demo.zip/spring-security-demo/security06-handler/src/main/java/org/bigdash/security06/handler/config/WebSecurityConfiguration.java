package org.bigdash.security06.handler.config;

import javax.annotation.Resource;

import org.bigdash.security06.handler.component.MyAuthenticationProvider;
import org.bigdash.security06.handler.handler.MyAccessDeniedHandler;
import org.bigdash.security06.handler.handler.MyAuthenticationEntryPoint;
import org.bigdash.security06.handler.handler.MyAuthenticationFailureHandler;
import org.bigdash.security06.handler.handler.MyAuthenticationSuccessHandler;
import org.bigdash.security06.handler.handler.MyInvalidSessionStrategy;
import org.bigdash.security06.handler.handler.MyLogoutSuccessHandler;
import org.bigdash.security06.handler.handler.MySessionInformationExpiredStrategy;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class WebSecurityConfiguration extends WebSecurityConfigurerAdapter {

    @Resource
    private MyAuthenticationProvider myAuthenticationProvider;
    @Resource
    private MyAuthenticationSuccessHandler myAuthenticationSuccessHandler;
    @Resource
    private MyAuthenticationFailureHandler myAuthenticationFailureHandler;
    @Resource
    private MyAccessDeniedHandler myAccessDeniedHandler;
    @Resource
    private MyLogoutSuccessHandler myLogoutSuccessHandler;
    @Resource
    private MyAuthenticationEntryPoint myAuthenticationEntryPoint;
    @Resource
    private MyInvalidSessionStrategy myInvalidSessionStrategy;
    @Resource
    private MySessionInformationExpiredStrategy mySessionInformationExpiredStrategy;

    @Override
    public void configure(WebSecurity web) {
        // 设置拦截忽略文件夹，可以对静态资源放行
        web.ignoring().antMatchers("/js/**", "/css/**", "/images/**");
    }

    @Override
    public void configure(AuthenticationManagerBuilder auth) {
        auth.authenticationProvider(myAuthenticationProvider);
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.formLogin()
            // 登录成功处理器（handler与forward只能选一种使用）
            .successHandler(myAuthenticationSuccessHandler)
            // 登录失败处理器（handler与forward只能选一种使用）
            .failureHandler(myAuthenticationFailureHandler);

        // 无权访问
        http.exceptionHandling().accessDeniedHandler(myAccessDeniedHandler);

        // 未登陆
        http.exceptionHandling().authenticationEntryPoint(myAuthenticationEntryPoint);

        // 退出登录
        http.logout().logoutSuccessHandler(myLogoutSuccessHandler);

        // session处理
        http.sessionManagement()
            // 登录超时
            .invalidSessionStrategy(myInvalidSessionStrategy)
            // 同一账号同时登录最大用户数
            .maximumSessions(1)
            // 顶号处理
            .expiredSessionStrategy(mySessionInformationExpiredStrategy);

        http.authorizeRequests()
            // admin角色才能访问account
            .antMatchers("/account").hasRole("admin")
            // 所有请求都必须被认证（登录）
            .anyRequest().authenticated();

        // 关闭csrf保护
        http.csrf().disable();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

}