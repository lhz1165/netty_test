package org.bigdash.security06.handler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 访问：localhost:8080
 *
 * 用户名：admin
 *
 * 密码：123456
 */
@SpringBootApplication
public class Security06Application {

    public static void main(String[] args) {
        SpringApplication.run(Security06Application.class, args);
    }

}