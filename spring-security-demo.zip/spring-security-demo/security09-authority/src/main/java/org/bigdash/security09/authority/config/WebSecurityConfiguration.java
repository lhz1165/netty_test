package org.bigdash.security09.authority.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class WebSecurityConfiguration extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        // 自定义登录逻辑，执行自定义的UserDetailsService
        http.formLogin()
            // 登录成功跳转（必须是POST请求）
            .successForwardUrl("/toMain");

        http.authorizeRequests()
            // 必须有admin权限，大小写敏感
            // .antMatchers("/toAdmin").hasAuthority("admin")
            // 必须有admin角色，大小写敏感
            // .antMatchers("/toAdmin").hasRole("admin")
            // 指定ip地址
            .antMatchers("/toAdmin").hasIpAddress("127.0.0.1")
            // 所有请求都必须被认证（登录）
            .anyRequest().authenticated();

        // 403页面
        http.exceptionHandling().accessDeniedPage("/403.html");

        // 关闭csrf保护
        http.csrf().disable();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

}