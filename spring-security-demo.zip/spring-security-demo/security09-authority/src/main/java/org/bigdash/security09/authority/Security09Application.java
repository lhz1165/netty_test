package org.bigdash.security09.authority;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 访问：localhost:8080
 *
 * 用户名：admin
 *
 * 密码：123456
 */
@SpringBootApplication
public class Security09Application {

    public static void main(String[] args) {
        SpringApplication.run(Security09Application.class, args);
    }

}