package org.bigdash.security09.authority.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class MyController {

    @PostMapping("toMain")
    public String toMain() {
        return "main";
    }

    @GetMapping("toAdmin")
    public String toAdmin() {
        return "admin";
    }

}
