package org.bigdash.security14.smscode.exception;

import org.springframework.security.core.AuthenticationException;

public class MyAuthenticationException extends AuthenticationException {
    private static final long serialVersionUID = 7171480099879976230L;

    public MyAuthenticationException(String message) {
        super(message);
    }
}
