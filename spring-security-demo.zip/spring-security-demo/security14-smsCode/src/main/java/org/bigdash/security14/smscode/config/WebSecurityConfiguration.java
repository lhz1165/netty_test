package org.bigdash.security14.smscode.config;

import javax.annotation.Resource;

import org.bigdash.security14.smscode.component.PasswordAuthenticationProvider;
import org.bigdash.security14.smscode.component.sms.SmsAuthenticationFilter;
import org.bigdash.security14.smscode.component.sms.SmsAuthenticationProvider;
import org.bigdash.security14.smscode.component.sms.SmsCodeValidateFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
public class WebSecurityConfiguration extends WebSecurityConfigurerAdapter {

    @Resource
    private PasswordAuthenticationProvider passwordAuthenticationProvider;
    @Resource
    private SmsAuthenticationProvider smsAuthenticationProvider;
    @Resource
    private SmsCodeValidateFilter smsCodeValidateFilter;
    @Resource
    private SmsAuthenticationFilter smsAuthenticationFilter;

    @Override
    protected void configure(AuthenticationManagerBuilder auth) {
        auth.authenticationProvider(passwordAuthenticationProvider);
        auth.authenticationProvider(smsAuthenticationProvider);
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        // 自定义登录逻辑，执行自定义的UserDetailsService
        http.formLogin();

        // 添加自定义过滤器
        http.addFilterAfter(smsCodeValidateFilter, UsernamePasswordAuthenticationFilter.class);
        http.addFilterAfter(smsAuthenticationFilter, SmsCodeValidateFilter.class);

        http.authorizeRequests()
            // 放行短信登录
            .antMatchers("/smsLogin").permitAll()
            // 所有请求都必须被认证（登录）
            .anyRequest().authenticated();

        // 关闭csrf保护
        http.csrf().disable();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

}