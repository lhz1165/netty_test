package org.bigdash.security11.enablesecurity.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    @PreAuthorize("hasAuthority('admin')")
    @PostMapping("/users/add")
    public String addUser() {
        return "添加用户成功";
    }

    @GetMapping("/users")
    public String listUsers() {
        return "用户列表";
    }

    @GetMapping("/users/{userId}")
    public String listUsers(@PathVariable Integer userId) {
        return "用户详情";
    }

    @PutMapping("/users")
    public String updateUser() {
        return "更新用户成功";
    }

    @DeleteMapping("/users")
    public String deleteUser() {
        return "删除用户成功";
    }

}
