package org.bigdash.security11.enablesecurity.controller;

import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class MyController {

    @PreAuthorize("hasAuthority('admin')")
    @PostMapping("toMain")
    public String toMain() {
        return "main";
    }

    @Secured("ROLE_admin")
    // @RolesAllowed("admin")
    // @PreAuthorize("hasRole('ROLE_admin')") // 也可以这样写
    // @PreAuthorize("hasRole('admin')") // 还可以这样写
    @GetMapping("toAdmin")
    public String toAdmin() {
        return "admin";
    }

}
