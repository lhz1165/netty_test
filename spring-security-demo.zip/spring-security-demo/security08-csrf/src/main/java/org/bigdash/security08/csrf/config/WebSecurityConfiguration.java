package org.bigdash.security08.csrf.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.csrf.CsrfFilter;

/**
 * @see CsrfFilter
 */
@Configuration
public class WebSecurityConfiguration extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.formLogin()
            // 自定义登录页面
            .loginPage("/myLogin.html")
            // 自定义登录逻辑，与页面表单的action地址保持一致
            .loginProcessingUrl("/myLogin")
            // 登录成功之后跳转路径
            .defaultSuccessUrl("/");

        http.authorizeRequests()
            // 不拦截自定义登录页面
            .antMatchers("/myLogin.html").permitAll()
            // 所有请求都必须被认证（登录）
            .anyRequest().authenticated();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

}