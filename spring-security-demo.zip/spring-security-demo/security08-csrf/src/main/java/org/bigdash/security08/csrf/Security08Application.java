package org.bigdash.security08.csrf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 访问：localhost:8080
 *
 * 用户名：admin
 *
 * 密码：123456
 */
@SpringBootApplication
public class Security08Application {

    public static void main(String[] args) {
        SpringApplication.run(Security08Application.class, args);
    }

}