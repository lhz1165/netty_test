package org.bigdash.security07.matcher.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {

    @GetMapping("/")
    public String index() {
        return "首页!";
    }

    @GetMapping("/news/list")
    public String listNews() {
        return "查看新闻!";
    }

    @GetMapping("/goods/add")
    public String addGoods() {
        return "添加商品成功!";
    }

}
