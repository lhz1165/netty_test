package org.bigdash.security07.matcher.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class WebSecurityConfiguration extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        // 自定义登录逻辑，执行自定义的UserDetailsService
        http.formLogin();

        http.authorizeRequests()
            // ant表达式
            .antMatchers("/news/**").permitAll()

            // 正则表达式
            //.regexMatchers(HttpMethod.GET, "/news/.*").anonymous()

            // 支持配置servletPath
            // .mvcMatchers(HttpMethod.GET, "/news/**").servletPath("/").permitAll()

            // 所有请求都必须被认证（登录）
            .anyRequest().authenticated();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

}