package org.bigdash.security03.loginforward;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 访问：localhost:8080
 *
 * 用户名：admin
 *
 * 密码：123456
 */
@SpringBootApplication
public class Security03Application {

    public static void main(String[] args) {
        SpringApplication.run(Security03Application.class, args);
    }

}