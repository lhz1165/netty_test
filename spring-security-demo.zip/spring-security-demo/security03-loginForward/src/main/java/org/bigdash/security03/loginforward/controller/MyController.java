package org.bigdash.security03.loginforward.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {

    @PostMapping("toMain")
    public String toMain() {
        return "登录成功!";
    }

    @PostMapping("toError")
    public String toError() {
        return "抱歉, 登录失败!";
    }

}
