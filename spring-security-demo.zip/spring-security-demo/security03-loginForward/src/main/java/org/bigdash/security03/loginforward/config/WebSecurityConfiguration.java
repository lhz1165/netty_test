package org.bigdash.security03.loginforward.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class WebSecurityConfiguration extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        // 自定义登录逻辑，执行自定义的UserDetailsService
        http.formLogin()
            // 登录成功跳转（必须是POST请求）
            .successForwardUrl("/toMain")
            // 登录失败跳转（必须是POST请求）
            .failureForwardUrl("/toError");
        // TODO 如果想要重定向，可通过handler自己实现

        http.authorizeRequests()
            // 所有请求都必须被认证（登录）
            .anyRequest().authenticated();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

}