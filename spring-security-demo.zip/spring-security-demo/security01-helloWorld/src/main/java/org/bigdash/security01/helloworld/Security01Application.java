package org.bigdash.security01.helloworld;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 访问：localhost:8080
 *
 * 用户名：user
 *
 * 密码：控制台随机生成
 */
@SpringBootApplication
public class Security01Application {

    public static void main(String[] args) {
        SpringApplication.run(Security01Application.class, args);
    }

}