package org.bigdash.security16.kedou.passport;

import com.shunwang.passportsdk.factory.ResponseFactory;

public class PassportResponseFactory extends ResponseFactory {

    private static class SigletonHolder {
        private static final PassportResponseFactory INSTANCE = new PassportResponseFactory();
    }

    public static PassportResponseFactory getInstance() {
        return SigletonHolder.INSTANCE;
    }

    private PassportResponseFactory() {}

}
