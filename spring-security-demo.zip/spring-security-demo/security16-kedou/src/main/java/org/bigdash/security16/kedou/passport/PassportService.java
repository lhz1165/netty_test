package org.bigdash.security16.kedou.passport;

import org.springframework.stereotype.Component;

import com.shunwang.passportsdk.passport.login.LoginRequest;
import com.shunwang.passportsdk.passport.login.LoginResponse;
import com.shunwang.passportsdk.passport.login.LoginService;
import com.shunwang.passportsdk.passport.query.QueryRequest;
import com.shunwang.passportsdk.passport.query.QueryResponse;
import com.shunwang.passportsdk.passport.query.QueryService;

@Component
public class PassportService {

    public QueryResponse getlUserInfo(String userName) {
        QueryRequest request = PassportRequestFactory.getInstance().createQueryRequest();
        request.setUserName(userName);
        QueryService queryService = new QueryService();
        queryService.setResponseFactory(PassportResponseFactory.getInstance());
        return queryService.service(request);
    }

    public LoginResponse login(String userName, String password) {
        LoginRequest loginRequest = PassportRequestFactory.getInstance().createLoginRequest();
        loginRequest.setUserName(userName);
        loginRequest.setPassword(password);
        loginRequest.setLoginIp("192.168.1.2");
        LoginService loginService = new LoginService();
        loginService.setResponseFactory(PassportResponseFactory.getInstance());
        return loginService.service(loginRequest);
    }

}
