package org.bigdash.security16.kedou.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.bigdash.security16.kedou.component.PropertiesUtil;
import org.bigdash.security16.kedou.passport.PassportService;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.alibaba.fastjson.JSON;
import com.shunwang.baseStone.sso.context.SSOContext;
import com.shunwang.baseStone.sso.request.TicketRequest;
import com.shunwang.baseStone.sso.response.TicketResponse;
import com.shunwang.baseStone.sso.util.CookieUtil;
import com.shunwang.passportsdk.passport.login.LoginResponse;
import com.shunwang.passportsdk.passport.query.QueryResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class MyController {

    private static final String S_Tick_Name = "sso.ticket";

    @Resource
    private PropertiesUtil propertiesUtil;
    @Resource
    private PassportService passportService;

    @GetMapping("login.html")
    public String login(Model model) {
        model.addAttribute("local_url", propertiesUtil.getLocalUrl());
        model.addAttribute("ssoSiteId", SSOContext.getSiteId());
        return "login";
    }

    @GetMapping("/")
    public String index() {
        QueryResponse queryResponse = passportService.getlUserInfo("test007");
        log.info("蝌蚪账号信息：{}", JSON.toJSONString(queryResponse));

        LoginResponse loginResponse = passportService.login("test007", "123456");
        log.info("蝌蚪接口登录返回：{}", JSON.toJSONString(loginResponse));

        return "main";
    }

    @GetMapping("ssoResult")
    public String ssoResult(HttpServletRequest request, HttpServletResponse response, Model model) {
        String ticketId = request.getParameter("ticketId");
        String token = request.getParameter("tockenId");
        if (!isTicketExist(request, ticketId)) {
            // 保存到ticket到cookie
            CookieUtil.setCookie(response, S_Tick_Name, ticketId);

            TicketRequest ticketRequest = new TicketRequest(ticketId, token);
            TicketResponse ticketResponse = ticketRequest.execute();
            // 登录成功
            if (ticketResponse != null) {
                // TODO 查询用户权限
                List<GrantedAuthority> authorities = AuthorityUtils.commaSeparatedStringToAuthorityList("addUser");
                // 封装用户登录信息
                PreAuthenticatedAuthenticationToken authentication =
                    new PreAuthenticatedAuthenticationToken(ticketResponse.getUserName(), null, authorities);
                SecurityContextHolder.getContext().setAuthentication(authentication);

                // 登录成功，跳转到首页
                return "redirect:" + request.getContextPath();
            }
        }

        return "login";
    }

    private boolean isTicketExist(HttpServletRequest req, String ticketId) {
        if (StringUtils.isBlank(ticketId)) {
            return false;
        }

        Cookie oldTicket = CookieUtil.getCookie(req, S_Tick_Name);
        return oldTicket != null && ticketId.equals(oldTicket.getValue());
    }

}
