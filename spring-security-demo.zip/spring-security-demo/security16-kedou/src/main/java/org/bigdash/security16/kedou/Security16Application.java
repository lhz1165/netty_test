package org.bigdash.security16.kedou;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 在浏览器中打开下面的链接试试
 *
 * https://sso.kedou.com/login.do?callbackUrl=http://localhost.yun.com:8080/ssoResult&site_id=diskless_focus&loginType=quickLogin
 *
 * https://sso.kedou.com/login.do?callbackUrl=http://localhost.yun.com:8080/ssoResult&site_id=Passport&loginType=quickLogin
 *
 * https://sso.kedou.com/login.do?callbackUrl=http://localhost.yun.com:8080/ssoResult&site_id=weihuyun&loginType=quickLogin&loginMode=smsLogin&loginCssUrl=https://staticwhy.icafe8.com/console/sso/style/sso.css
 */
@SpringBootApplication
public class Security16Application {

    public static void main(String[] args) {
        SpringApplication.run(Security16Application.class, args);
    }

}