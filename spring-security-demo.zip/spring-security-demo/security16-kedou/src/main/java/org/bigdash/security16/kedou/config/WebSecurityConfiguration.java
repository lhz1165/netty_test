package org.bigdash.security16.kedou.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
public class WebSecurityConfiguration extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        // 自定义登录逻辑，执行自定义的UserDetailsService
        http.formLogin().loginPage("/login.html");

        // 退出登录跳转到登录页
        http.logout().logoutSuccessUrl("/login.html");

        http.authorizeRequests()
            // 不拦截自定义登录页面
            .antMatchers("/login.html").permitAll()
            .antMatchers("/ssoResult").permitAll()
            .antMatchers("/logout").permitAll()
            // 所有请求都必须被认证（登录）
            .anyRequest().authenticated();

        // 关闭csrf保护
        http.csrf().disable();
    }

}