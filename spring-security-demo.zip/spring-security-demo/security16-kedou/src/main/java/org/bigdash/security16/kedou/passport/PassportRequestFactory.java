package org.bigdash.security16.kedou.passport;

import com.shunwang.passportsdk.factory.RequestFactory;

public class PassportRequestFactory extends RequestFactory {

    private static class SigletonHolder {
        private static final PassportRequestFactory INSTANCE = new PassportRequestFactory();
    }

    public static PassportRequestFactory getInstance() {
        return SigletonHolder.INSTANCE;
    }

    private PassportRequestFactory() {}

}
