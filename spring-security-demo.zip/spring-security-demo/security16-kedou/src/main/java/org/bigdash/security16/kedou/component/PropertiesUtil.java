package org.bigdash.security16.kedou.component;

import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component("propertiesUtil")
public class PropertiesUtil {

    private String localUrl = "http://localhost.yun.com:8080";

}
