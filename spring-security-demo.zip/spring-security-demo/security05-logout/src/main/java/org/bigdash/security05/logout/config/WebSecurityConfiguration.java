package org.bigdash.security05.logout.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class WebSecurityConfiguration extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.formLogin()
            // 登录成功跳转（必须是POST请求）
            .successForwardUrl("/toMain");

        http.logout()
            // 退出成功跳转页面
            .logoutSuccessUrl("/login");

        http.authorizeRequests()
            // 所有请求都必须被认证（登录）
            .anyRequest().authenticated();

        // 关闭csrf保护
        http.csrf().disable();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

}