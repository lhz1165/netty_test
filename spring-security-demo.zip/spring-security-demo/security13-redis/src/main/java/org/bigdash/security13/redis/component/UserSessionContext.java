package org.bigdash.security13.redis.component;

public class UserSessionContext {

    /**
     * 保存在数据库中的seesionId
     */
    public static String SEESION_ID = "";

}
