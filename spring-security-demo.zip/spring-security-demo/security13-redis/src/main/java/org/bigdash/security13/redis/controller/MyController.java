package org.bigdash.security13.redis.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.bigdash.security13.redis.component.UserSessionContext;
import org.bigdash.security13.redis.component.UserSessionHelper;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {

    @Resource
    private UserSessionHelper userSessionHelper;

    @GetMapping("/")
    public String index(HttpServletRequest request) {
        // TODO 登录成功后，将当前登录用户的sessionId保存到用户表
        UserSessionContext.SEESION_ID = request.getSession().getId();
        return "首页!";
    }

    @GetMapping("kick")
    public void kick() {
        // 管理员修改用户权限、管理员禁用用户，可以踢出用户，让用户重新登录
        userSessionHelper.kickUser(1);
    }

}
