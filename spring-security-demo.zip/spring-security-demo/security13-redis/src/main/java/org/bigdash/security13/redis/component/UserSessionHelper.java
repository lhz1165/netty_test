package org.bigdash.security13.redis.component;

import javax.annotation.Resource;

import org.springframework.security.core.session.SessionInformation;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.stereotype.Component;

@Component
public class UserSessionHelper {
    @Resource
    private SessionRegistry sessionRegistry;

    /**
     * 踢出用户
     */
    public void kickUser(Integer userId) {
        if (userId == null) {
            return;
        }

        // TODO 根据userId查询seesionId
        String seesionId = UserSessionContext.SEESION_ID;
        // 会话信息
        SessionInformation sessionInformation = sessionRegistry.getSessionInformation(seesionId);
        // 会话过期
        sessionInformation.expireNow();
    }

}
